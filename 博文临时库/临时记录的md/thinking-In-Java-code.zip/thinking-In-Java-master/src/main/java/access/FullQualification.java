//: access/FullQualification.java
package access; /* Added by Eclipse.py */

public class FullQualification {
  public static void main(String[] args) {
    java.util.ArrayList list = new java.util.ArrayList();
  }
} ///:~
