//: access/mypackage/MyClass.java
package access.mypackage;

public class MyClass {
  // ...
} ///:~
