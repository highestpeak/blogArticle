//: access/Pie.java
package access; /* Added by Eclipse.py */
// The other class.

class Pie {
  void f() { System.out.println("Pie.f()"); }
} ///:~
