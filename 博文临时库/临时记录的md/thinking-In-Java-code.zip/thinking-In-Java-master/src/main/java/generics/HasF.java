//: generics/HasF.java
package generics; /* Added by Eclipse.py */

public class HasF {
  public void f() { System.out.println("HasF.f()"); }
} ///:~
