//: generics/Performs.java
package generics; /* Added by Eclipse.py */

public interface Performs {
  void speak();
  void sit();
} ///:~
