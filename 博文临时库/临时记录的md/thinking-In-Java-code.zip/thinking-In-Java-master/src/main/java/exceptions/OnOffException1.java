//: exceptions/OnOffException1.java
package exceptions; /* Added by Eclipse.py */
public class OnOffException1 extends Exception {} ///:~
